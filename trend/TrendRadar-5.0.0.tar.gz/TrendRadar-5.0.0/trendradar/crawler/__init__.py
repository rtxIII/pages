# coding=utf-8
"""
爬虫模块 - 数据抓取功能
"""

from trendradar.crawler.fetcher import DataFetcher

__all__ = ["DataFetcher"]
